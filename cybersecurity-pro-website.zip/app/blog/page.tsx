import Link from "next/link"

export default function Blog() {
  const posts = [
    { id: 1, title: "My OSCP Journey: Week 1", slug: "oscp-week-1" },
    { id: 2, title: "Top 5 Cybersecurity Trends in 2023", slug: "cybersecurity-trends-2023" },
    { id: 3, title: "Common VAPT Mistakes to Avoid", slug: "vapt-mistakes" },
    { id: 4, title: "How to Prepare for OSCP", slug: "prepare-for-oscp" },
    { id: 5, title: "The Importance of Regular Penetration Testing", slug: "importance-of-pentesting" },
  ]

  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="text-4xl font-bold mb-8 text-center">Blog</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {posts.map((post) => (
          <div key={post.id} className="bg-gray-800 p-6 rounded-lg">
            <h2 className="text-2xl font-bold mb-4">{post.title}</h2>
            <Link href={`/blog/${post.slug}`} className="text-blue-400 hover:underline">
              Read more
            </Link>
          </div>
        ))}
      </div>
    </div>
  )
}

