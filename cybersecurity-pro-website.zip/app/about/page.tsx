import Image from "next/image"
import Link from "next/link"
import { Github, Linkedin, Facebook, Twitter, BookOpen } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function About() {
  const socialLinks = [
    {
      name: "LinkedIn",
      url: "https://linkedin.com/in/your-profile",
      icon: Linkedin,
      color: "hover:text-[#0A66C2]",
    },
    {
      name: "Medium",
      url: "https://medium.com/@your-profile",
      icon: BookOpen,
      color: "hover:text-white",
    },
    {
      name: "GitHub",
      url: "https://github.com/your-profile",
      icon: Github,
      color: "hover:text-white",
    },
    {
      name: "Facebook",
      url: "https://facebook.com/your-profile",
      icon: Facebook,
      color: "hover:text-[#1877F2]",
    },
    {
      name: "X (Twitter)",
      url: "https://x.com/your-profile",
      icon: Twitter,
      color: "hover:text-white",
    },
  ]

  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="text-4xl font-bold mb-8 text-center">About Me</h1>
      <div className="flex flex-col md:flex-row items-center md:items-start gap-8">
        <Image
          src="/placeholder.svg?height=300&width=300"
          alt="Profile picture"
          width={300}
          height={300}
          className="rounded-full"
        />
        <div>
          <p className="mb-4">
            Hi, I'm [Your Name], a cybersecurity professional specializing in penetration testing and VAPT services.
            With over [X] years of experience in the field, I've helped numerous organizations identify and mitigate
            security vulnerabilities.
          </p>
          <p className="mb-4">
            I hold several industry certifications, including OSCP, and I'm passionate about sharing my knowledge
            through my blog and professional services.
          </p>
          <p className="mb-8">
            When I'm not testing systems or writing about cybersecurity, you can find me [your hobbies or interests].
          </p>

          <div className="border-t border-red-600 pt-8">
            <h2 className="text-2xl font-bold mb-4 text-red-400">Connect With Me</h2>
            <div className="flex flex-wrap gap-4">
              {socialLinks.map((social) => (
                <Button
                  key={social.name}
                  variant="outline"
                  className={`flex items-center gap-2 border-red-600 ${social.color} transition-colors`}
                  asChild
                >
                  <Link href={social.url} target="_blank" rel="noopener noreferrer">
                    <social.icon className="w-5 h-5" />
                    <span>{social.name}</span>
                  </Link>
                </Button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

