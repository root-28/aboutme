export default function Services() {
  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="text-4xl font-bold mb-8 text-center">Our Services</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-gray-800 p-6 rounded-lg">
          <h2 className="text-2xl font-bold mb-4 text-blue-400">Penetration Testing</h2>
          <p className="mb-4">
            Our expert team simulates real-world attacks to identify vulnerabilities in your systems, applications, and
            networks.
          </p>
          <ul className="list-disc list-inside">
            <li>Web Application Penetration Testing</li>
            <li>Network Penetration Testing</li>
            <li>Mobile Application Penetration Testing</li>
            <li>Cloud Infrastructure Penetration Testing</li>
          </ul>
        </div>
        <div className="bg-gray-800 p-6 rounded-lg">
          <h2 className="text-2xl font-bold mb-4 text-green-400">VAPT Services</h2>
          <p className="mb-4">
            Comprehensive Vulnerability Assessment and Penetration Testing to secure your entire IT infrastructure.
          </p>
          <ul className="list-disc list-inside">
            <li>Automated Vulnerability Scanning</li>
            <li>Manual Vulnerability Assessment</li>
            <li>Exploitation and Post-Exploitation</li>
            <li>Detailed Reporting and Remediation Guidance</li>
          </ul>
        </div>
        <div className="bg-gray-800 p-6 rounded-lg">
          <h2 className="text-2xl font-bold mb-4 text-purple-400">Cyber Security Exam Vouchers</h2>
          <p className="mb-4">
            We provide exam vouchers for various cybersecurity certifications to help advance your career.
          </p>
          <ul className="list-disc list-inside">
            <li>Ofsec all Exam Vouchers (OSCP) with discount</li>
            <li>CEH Exam Vouchers</li>
            <li>CompTIA Security+ Vouchers</li>
            <li>Elearn all Exam Vouchers(EJPv2)</li>
            <li>Alter_security all vauchers (CRTP)</li>
            <li>...All Exam Support...</li>
          </ul>
        </div>
      </div>
    </div>
  )
}

