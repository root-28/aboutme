import Link from "next/link"

export default function Header() {
  return (
    <header className="bg-gradient-to-r from-gray-900 to-black py-6 shadow-lg">
      <nav className="container mx-auto px-4 flex justify-between items-center">
        <Link href="/" className="text-2xl font-bold text-red-500 hover:text-red-400 transition-colors duration-300">
          CyberWatch Pro
        </Link>
        <ul className="flex space-x-8">
          {["Home", "Services", "Blog", "About Me", "Contact"].map((item) => (
            <li key={item}>
              <Link
                href={item === "Home" ? "/" : `/${item.toLowerCase().replace(" ", "-")}`}
                className="text-gray-300 hover:text-red-500 transition-colors duration-300 text-lg font-medium"
              >
                {item}
              </Link>
            </li>
          ))}
        </ul>
      </nav>
    </header>
  )
}

