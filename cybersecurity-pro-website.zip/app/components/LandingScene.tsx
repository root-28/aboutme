"use client"

import { useRef, useMemo } from "react"
import { Canvas, useFrame } from "@react-three/fiber"
import { OrbitControls, Sphere } from "@react-three/drei"
import * as THREE from "three"

function Node({ position }: { position: [number, number, number] }) {
  return (
    <Sphere args={[0.1, 16, 16]} position={position}>
      <meshBasicMaterial color="red" />
    </Sphere>
  )
}

function Connection({ start, end }: { start: [number, number, number]; end: [number, number, number] }) {
  const points = useMemo(() => [new THREE.Vector3(...start), new THREE.Vector3(...end)], [start, end])

  return (
    <line>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={points.length}
          array={new Float32Array(points.flatMap((p) => p.toArray()))}
          itemSize={3}
        />
      </bufferGeometry>
      <lineBasicMaterial color="red" />
    </line>
  )
}

function CyberNetwork() {
  const groupRef = useRef<THREE.Group>(null!)
  const nodeCount = 20
  const nodes = useMemo(() => {
    return Array.from(
      { length: nodeCount },
      () => [Math.random() * 4 - 2, Math.random() * 4 - 2, Math.random() * 4 - 2] as [number, number, number],
    )
  }, [])

  const connections = useMemo(() => {
    const result = []
    for (let i = 0; i < nodeCount; i++) {
      for (let j = i + 1; j < nodeCount; j++) {
        if (Math.random() > 0.75) {
          result.push([nodes[i], nodes[j]])
        }
      }
    }
    return result
  }, [nodes])

  useFrame((state, delta) => {
    if (groupRef.current) {
      groupRef.current.rotation.x += delta * 0.1
      groupRef.current.rotation.y += delta * 0.15
    }
  })

  return (
    <group ref={groupRef}>
      {nodes.map((pos, idx) => (
        <Node key={idx} position={pos} />
      ))}
      {connections.map(([start, end], idx) => (
        <Connection key={idx} start={start} end={end} />
      ))}
    </group>
  )
}

export default function LandingScene() {
  return (
    <div className="h-[60vh] w-full bg-black">
      <Canvas camera={{ position: [0, 0, 5] }}>
        <color attach="background" args={["#000000"]} />
        <ambientLight intensity={0.5} />
        <pointLight position={[10, 10, 10]} />
        <CyberNetwork />
        <OrbitControls enableZoom={false} />
      </Canvas>
    </div>
  )
}

