import Link from "next/link"
import { Button } from "@/components/ui/button"
import dynamic from "next/dynamic"
import Image from "next/image"

const LandingScene = dynamic(() => import("./components/LandingScene"), { ssr: false })

export default function Home() {
  return (
    <div className="container mx-auto px-4">
      <section className="py-10 text-center relative">
        <LandingScene />
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <h1 className="text-5xl font-bold mb-4 text-red-600">Secure Your Digital Assets</h1>
          <p className="text-xl mb-8 text-gray-300">Professional Penetration Testing & VAPT Services</p>
          <Button asChild className="bg-red-600 hover:bg-red-700">
            <Link href="/contact">Get Started</Link>
          </Button>
        </div>
      </section>

      <section className="py-16">
        <h2 className="text-3xl font-bold mb-8 text-center text-red-600">Our Services</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-gray-900 p-6 rounded-lg border border-red-600">
            <h3 className="text-2xl font-bold mb-4 text-red-400">Penetration Testing</h3>
            <p className="text-gray-300">Identify vulnerabilities in your systems before hackers do.</p>
          </div>
          <div className="bg-gray-900 p-6 rounded-lg border border-red-600">
            <h3 className="text-2xl font-bold mb-4 text-red-400">VAPT Services</h3>
            <p className="text-gray-300">Comprehensive Vulnerability Assessment and Penetration Testing.</p>
          </div>
          <div className="bg-gray-900 p-6 rounded-lg border border-red-600">
            <h3 className="text-2xl font-bold mb-4 text-red-400">Exam Vouchers</h3>
            <p className="text-gray-300">Get vouchers for top cybersecurity certifications.</p>
          </div>
        </div>
      </section>

      <section className="py-16">
        <h2 className="text-3xl font-bold mb-8 text-center text-red-600">Certifications</h2>
        <div className="flex justify-center items-center gap-8 flex-wrap">
          <div className="text-center">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/ofsecdownload.jpg-gtCDcuWin2SvLoVYVKajnFHMaTjZQr.jpeg"
              alt="OSCP+ Certification"
              width={200}
              height={200}
              className="mb-4"
            />
            <h3 className="text-xl font-bold text-red-400">OSCP+</h3>
            <p className="text-gray-300">Offensive Security Certified Professional Plus</p>
          </div>
          <div className="text-center">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/eJPT.jpg-5usNPQd6WozvmmIreVmSRfiEYsLJxf.webp"
              alt="eJPT Certification"
              width={200}
              height={200}
              className="mb-4"
            />
            <h3 className="text-xl font-bold text-red-400">eJPT v2</h3>
            <p className="text-gray-300">eLearnSecurity Junior Penetration Tester</p>
          </div>
        </div>
      </section>
    </div>
  )
}

